import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connect-to-junxure',
  templateUrl: './connect-to-junxure.component.html',
  styleUrls: ['./connect-to-junxure.component.scss']
})
export class ConnectToJunxureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
