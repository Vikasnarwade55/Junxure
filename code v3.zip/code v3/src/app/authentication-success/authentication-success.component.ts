import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authentication-success',
  templateUrl: './authentication-success.component.html',
  styleUrls: ['./authentication-success.component.scss']
})
export class AuthenticationSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
